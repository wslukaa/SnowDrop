package com.ihs.message_2013011392.managers;

public class ReceiptManager {

}
