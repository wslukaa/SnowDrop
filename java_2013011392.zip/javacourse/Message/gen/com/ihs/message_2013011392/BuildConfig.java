/** Automatically generated file. DO NOT MODIFY */
package com.ihs.message_2013011392;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}